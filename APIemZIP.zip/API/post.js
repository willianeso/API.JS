// importa a bibliteca axios, que facilita as requisições HTTP
const axios = require('axios');

// URL da API onde vamos enviar os dados
const url = "https://jsonplaceholder.typicode.com/posts";

// Dados que queremos enviar para API (um novo post, por exemplo)
const novoPost = {
    title: "Aprendendo integraçaõ de API",
    body: "Não aguento mais java e API e Ítala",
    userId: 1
}

// fazendo uma requisição POST para criar um novo recurso na API
axios.post(url, novoPost)
    .then(response => {
        console.log("Recurso criado com sucesso: ")
        console.log(response.data)
    })
    .catch(error =>{
        console.error(`Erro ao tentar criar o recurso: ${error}`)
    })